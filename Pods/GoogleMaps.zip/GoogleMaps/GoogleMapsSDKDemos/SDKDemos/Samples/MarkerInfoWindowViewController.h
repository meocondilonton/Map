#import <UIKit/UIKit.h>

@interface MarkerInfoWindowViewController : UIViewController

@end
